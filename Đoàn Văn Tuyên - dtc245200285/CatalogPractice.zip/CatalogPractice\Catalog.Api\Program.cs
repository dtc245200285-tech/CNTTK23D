﻿var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

var products = new List<ProductDto>
{
    new(1, "Giao trinh Lap trinh phan tan", "Tai lieu mon hoc", 150000),
    new(2, "Cam nang Thiet ke RESTful API", "Tai lieu tham khao", 95000),
    new(3, "Bai tap thuc hanh .NET", "Bo bai tap co loi giai", 120000)
};

app.MapGet("/", () => Results.Ok(new
{
    service = "Catalog API",
    status = "Running"
}));

app.MapGet("/api/products", (string? keyword) =>
{
    if (string.IsNullOrWhiteSpace(keyword))
    {
        return Results.Ok(products);
    }

    var filtered = products
        .Where(p => p.Name.Contains(keyword.Trim(), StringComparison.OrdinalIgnoreCase))
        .ToList();
    return Results.Ok(filtered);
});

app.MapGet("/api/products/{id:int}", (int id) =>
{
    var product = products.FirstOrDefault(p => p.Id == id);
    return product is null
        ? Results.NotFound(new ApiError("PRODUCT_NOT_FOUND", $"Khong tim thay san pham co id = {id}"))
        : Results.Ok(product);
});

app.MapPost("/api/products", (CreateProductRequest request) =>
{
    if (string.IsNullOrWhiteSpace(request.Name) || request.Price <= 0)
    {
        return Results.BadRequest(new ApiError(
            "INVALID_PRODUCT",
            "Ten san pham khong duoc de trong va gia phai lon hon 0."));
    }

    var nextId = products.Count == 0 ? 1 : products.Max(p => p.Id) + 1;
    var created = new ProductDto(
        nextId,
        request.Name.Trim(),
        request.Description?.Trim() ?? "",
        request.Price);

    products.Add(created);
    return Results.Created($"/api/products/{created.Id}", created);
});

app.Run();

record ProductDto(int Id, string Name, string Description, decimal Price);
record CreateProductRequest(string Name, string Description, decimal Price);
record ApiError(string Code, string Message);
