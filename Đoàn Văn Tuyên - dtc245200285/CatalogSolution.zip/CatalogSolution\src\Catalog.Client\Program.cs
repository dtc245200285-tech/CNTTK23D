﻿using System.Net;
using System.Net.Http.Json;

var baseUrl = args.Length > 0 ? args[0] : "http://localhost:5100";
using var http = new HttpClient { BaseAddress = new Uri(baseUrl) };

// Buoc 1: doc danh sach san pham
var products = await http.GetFromJsonAsync<List<ProductDto>>("/api/products");
Console.WriteLine("Danh sach san pham:");
foreach (var p in products ?? [])
{
    Console.WriteLine($" [{p.Id}] {p.Name} - {p.Price:N0} VND");
}

// Buoc 2: tao san pham moi
var createRequest = new CreateProductRequest(
    "Kien truc Microservices voi .NET",
    "Sach chuyen sau",
    250000);
var createResponse = await http.PostAsJsonAsync("/api/products", createRequest);
if (createResponse.StatusCode == HttpStatusCode.Created)
{
    var created = await createResponse.Content.ReadFromJsonAsync<ProductDto>();
    Console.WriteLine($"\nDa tao san pham moi: [{created?.Id}] {created?.Name}");
}

// Buoc 3: doc lai mot san pham
var detail = await http.GetFromJsonAsync<ProductDto>("/api/products/1");
Console.WriteLine($"\nChi tiet san pham 1: {detail?.Name}");

// Buoc 4: gui yeu cau sai de quan sat loi 400
var invalidResponse = await http.PostAsJsonAsync("/api/products",
    new CreateProductRequest("", "", -1));
Console.WriteLine($"\nThu gui du lieu sai: {(int)invalidResponse.StatusCode} {invalidResponse.StatusCode}");
var invalidError = await invalidResponse.Content.ReadFromJsonAsync<ApiError>();
Console.WriteLine($"{invalidError?.Code}: {invalidError?.Message}");

record ProductDto(int Id, string Name, string Description, decimal Price);
record CreateProductRequest(string Name, string Description, decimal Price);
record ApiError(string Code, string Message);